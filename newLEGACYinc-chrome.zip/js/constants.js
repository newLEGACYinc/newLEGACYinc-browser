// hitbox
var HITBOX_USERNAME = 'newLEGACYinc';
var HITBOX_NOTIFICATION_ID = 'hitbox';
var HITBOX_URL = 'http://www.hitbox.tv/' + HITBOX_USERNAME;

// Twitch
var TWITCH_USERNAME = 'newLEGACYinc';
var TWITCH_URL = 'http://www.twitch.tv/' + TWITCH_USERNAME;
var TWITCH_URL_SEARCH_PATTERN = '*://*.twitch.tv/newLEGACYinc*';
var TWITCH_NOTIFICATION_ID = 'twitch';

// Twitter
var TWITTER_URL = 'http://twitter.com/newLEGACYinc';
var TWITTER_URL_SEARCH_PATTERN = '*://*.twitter.com/newLEGACYinc*';

// YouTube
var YOUTUBE_USERNAME = 'newLEGACYinc';
var YOUTUBE_NOTIFICATION_ID = 'YouTube';
var YOUTUBE_URL = 'http://www.youtube.com/user/newLEGACYinc/videos';
var YOUTUBE_URL_SEARCH_PATTERN = '*://*.youtube.com/user/newLEGACYinc*'